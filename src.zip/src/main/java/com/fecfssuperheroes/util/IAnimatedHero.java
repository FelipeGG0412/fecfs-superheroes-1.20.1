package com.fecfssuperheroes.util;

import dev.kosmx.playerAnim.api.layered.IAnimation;
import dev.kosmx.playerAnim.api.layered.ModifierLayer;

public interface IAnimatedHero {
    ModifierLayer<IAnimation> fecfsSuperheroes_getModAnimation();
}
